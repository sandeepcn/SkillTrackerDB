'use strict';
var mongoose = require('mongoose');
var Schema=mongoose.Schema;

var AssociateSchema = Schema({
    _id: mongoose.Schema.Types.ObjectId,	
    associateId: {type: Number, required: 'Associate id is required',index:{unique:true}},
    associateName: String,
	emailAddress: String,
    mobileNumber: Number,
	strength: String,
	weakness: String,
	remarks: String,
	picture: String,
	associateStatus: String,	
	associateLevel: String,
    profilePicture: Buffer,	
	associateSkills:[{skill:{type: Schema.ObjectId, ref: 'Skills'},skillRating:Number}],
    createdDt: {type: Date,default: Date.now}
});

 
var SkillsSchema =  Schema({
	_id: mongoose.Schema.Types.ObjectId,
	skillName: {type: String, required: 'Skill Name is required'},	
	createdDt: {type: Date,default: Date.now}
});

var Skills=mongoose.model('Skills',SkillsSchema);
module.exports.Skills = Skills;

var Associate=mongoose.model('Associate',AssociateSchema);
module.exports.Associate = Associate;
