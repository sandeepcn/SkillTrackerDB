import {Skill} from './Skill';

export class AssociateSkills {	
	constructor() {}
	_id:string;    
	associateId:string;
	skill:Skill;
	skillRating:number;	
}