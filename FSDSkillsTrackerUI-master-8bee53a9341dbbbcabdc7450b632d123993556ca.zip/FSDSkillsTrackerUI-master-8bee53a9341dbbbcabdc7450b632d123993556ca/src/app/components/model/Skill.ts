export class Skill {	
	constructor() {}
	_id:string;    
	skillName:string;
	skillRating:number;
}