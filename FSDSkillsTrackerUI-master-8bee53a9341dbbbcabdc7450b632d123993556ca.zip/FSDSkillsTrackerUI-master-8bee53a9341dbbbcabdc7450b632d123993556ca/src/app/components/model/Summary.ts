export class Summary
{
    public registeredCandidates :number;
    public femaleCandidates :number;
    public maleCandidates :number;
    public fresherCandidates :number;
    public ratedCandidates :number;
    public maleRatedCandidates :number;
    public femaleRatedCandidates :number;
    public l1RatedCandidates :number;
    public l2RatedCandidates :number;
    public l3RatedCandidates :number;
    
}
