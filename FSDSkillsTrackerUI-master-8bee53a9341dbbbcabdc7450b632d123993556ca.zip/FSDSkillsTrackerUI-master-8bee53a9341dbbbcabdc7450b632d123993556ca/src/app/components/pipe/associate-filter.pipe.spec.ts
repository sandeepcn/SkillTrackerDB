import { AssociateFilterPipe } from './associate-filter.pipe';

describe('AssociateFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AssociateFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
