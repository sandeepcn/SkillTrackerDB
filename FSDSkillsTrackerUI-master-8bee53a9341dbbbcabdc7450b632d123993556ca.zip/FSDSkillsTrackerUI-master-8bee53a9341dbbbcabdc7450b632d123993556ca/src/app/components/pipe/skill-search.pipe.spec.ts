import { SkillSearchPipe } from './skill-search.pipe';

describe('SkillSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new SkillSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
