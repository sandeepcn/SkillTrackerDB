import {Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {AssociateService} from '../service/associate.service';
import {Associate} from '../model/Associate';
import {Summary} from '../model/Summary';

@Component({
  selector: 'app-skills-dashboard',
  templateUrl: './skills-dashboard.component.html',   
  styleUrls: ['./skills-dashboard.component.css']
})
export class SkillsDashboardComponent implements OnInit {

    constructor(private associateService:AssociateService,private router: Router) { }

	associateArray:Associate[];
	associate:Associate;
	summary:Summary;
		
    ngOnInit() {
		this.loadAllAssociates();
		this.getSummaryDetails();				
    }  	

	private getSummaryDetails()
	{
		this.summary = new Summary();		
		this.summary.registeredCandidates=2;
		this.summary.femaleCandidates=0;
		this.summary.maleCandidates=2;
		this.summary.fresherCandidates=2;
		this.summary.ratedCandidates=1;
		this.summary.maleRatedCandidates=2;
		this.summary.femaleRatedCandidates=1;
		this.summary.l1RatedCandidates=1;
		this.summary.l2RatedCandidates=1;
		this.summary.l3RatedCandidates=1;				
    }

	loadAllAssociates():void{	  
	  this.associateService.getAllAssociates().subscribe(data => { 
		 this.associateArray=data;		 
		 
			for(var cnt=0;cnt<this.associateArray.length;cnt++){				
				if(this.associateArray[cnt].associateSkills!==null){
					let assocSkills="";
					for(var i=0;i<this.associateArray[cnt].associateSkills.length;i++){				assocSkills+=this.associateArray[cnt].associateSkills[i].skill.skillName+",";						
					}
					this.associateArray[cnt].assocSkills=assocSkills;				
				}				
			}		 
		   
	  });	  
	}	
	deleteAssociate(associate:Associate): void {
		console.log("Deleting Associate:"+associate._id);	  
		this.associateArray = this.associateArray.filter(h => h !== associate);
		this.associateService.deleteAssociate(associate).subscribe();
    }
}
