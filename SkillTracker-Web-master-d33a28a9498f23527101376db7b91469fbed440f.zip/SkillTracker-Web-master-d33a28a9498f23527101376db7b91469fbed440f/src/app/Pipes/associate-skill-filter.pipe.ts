import { Pipe, PipeTransform } from '@angular/core';
import {AssociateSkillMappingModel} from '../Model/AssociateSkillMappingModel'

@Pipe({
  name: 'associateSkillFilter'
})
export class AssociateSkillFilterPipe implements PipeTransform {

  public transform(values: AssociateSkillMappingModel[], filter: string): AssociateSkillMappingModel[] {
    
    if (!values || !values.length) return [];
    if (!filter) return values;
    // Filter items array, items which match will return true
    return values.filter(v => v.SkillName.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }

}
