import { TestBed, inject } from '@angular/core/testing';

import { AssociateServiceService } from './associate-service.service';
import { HttpModule } from '@angular/http';

describe('AssociateServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AssociateServiceService],imports:[HttpModule]
    });
  });

  it('should be created', inject([AssociateServiceService], (service: AssociateServiceService) => {
    expect(service).toBeTruthy();
  }));
});
