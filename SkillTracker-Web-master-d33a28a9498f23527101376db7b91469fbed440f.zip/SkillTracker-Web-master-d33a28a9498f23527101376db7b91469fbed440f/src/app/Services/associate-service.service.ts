import { Http, Response,RequestOptions,Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import {AssociateSkillsModel} from '../Model/AssociateSkillsModel' 
import {AssociateSkillMappingModel} from '../Model/AssociateSkillMappingModel'
import {DashBoardModel} from '../Model/DashBoardModel'
import { AppSettings} from '../Shared/AppSettings';

@Injectable()
export class AssociateServiceService {

  API_URL:string = AppSettings.API_ENDPOINT+ 'AssociateDetails/';
  constructor( private _http: Http) {
  }

  GetDashBoardData() {    
    return this._http.get(this.API_URL+'GetDashBoardData')
        .map(res => <DashBoardModel>res.json())
        .catch(this.handleError);
  }

  GetAssociateSkillInfo(param1:number) {    
    return this._http.get(this.API_URL+'GetAssociateSkillInfo?id='+param1.toString())
        .map(res => <AssociateSkillMappingModel[]>res.json())
        .catch(this.handleError);
  }

  GetAssociateSkillDetails(param1:number) {    
    return this._http.get(this.API_URL+'GetAssociateSkillDetails?id='+param1.toString())
        .map(res => <AssociateSkillsModel>res.json())
        .catch(this.handleError);
  }

  AddAssociateDetails(associate:AssociateSkillsModel)
  {
      
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = JSON.stringify(associate);
      return this._http.post(this.API_URL+'AddAssociateSkillDetails/', body, options )
          .map((res: Response) => res.json());
  }

  UpdateAssociateDetails(associate:AssociateSkillsModel)
  {
      
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = JSON.stringify(associate);
      return this._http.post(this.API_URL+'UpdateAssociateSkill/', body, options )
          .map((res: Response) => res.json());
  }

  DeleteAssociateDetails(id:number)
  {
      
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = JSON.stringify(id);
      return this._http.post(this.API_URL+'DeleteAssociate/', body, options )
          .map((res: Response) => res.json());
  }


  private handleError (error: Response | any) {
    console.error('ApiService::handleError', error);
    return Observable.throw(error);
  }
}
