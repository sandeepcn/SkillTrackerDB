import { TestBed, inject } from '@angular/core/testing';

import { SkillServiceService } from './skill-service.service';
import { HttpModule } from '@angular/http';

describe('SkillServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SkillServiceService],imports:[HttpModule]
    });
  });

  it('should be created', inject([SkillServiceService], (service: SkillServiceService) => {
    expect(service).toBeTruthy();
  }));
});
