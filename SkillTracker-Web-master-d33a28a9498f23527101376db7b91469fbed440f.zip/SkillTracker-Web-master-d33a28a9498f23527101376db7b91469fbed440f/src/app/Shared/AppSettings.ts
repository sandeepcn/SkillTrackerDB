export class AppSettings {
    //Local URL
    //  public static API_ENDPOINT='http://localhost:50851/api/';
   //Hoseted URL
    public static API_ENDPOINT='http://localhost:5050/api/';
 }