import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAssociateSkillComponent } from './add-associate-skill.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SkillSelectComponent } from '../skill-select/skill-select.component';
import { AssociateSkillFilterPipe } from '../../Pipes/associate-skill-filter.pipe';
import {SliderModule} from 'primeng/slider'; 
import {AssociateServiceService} from '../../Services/associate-service.service'
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageDisplayComponent } from '../../UI/message-display/message-display.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';

describe('AddAssociateSkillComponent', () => {
  let component: AddAssociateSkillComponent;
  let fixture: ComponentFixture<AddAssociateSkillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAssociateSkillComponent,SkillSelectComponent,AssociateSkillFilterPipe,MessageDisplayComponent ],
      imports:[ReactiveFormsModule,FormsModule,SliderModule,HttpModule,BrowserModule,RouterTestingModule,ConfirmDialogModule],
      providers:[AssociateServiceService,ConfirmationService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAssociateSkillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
