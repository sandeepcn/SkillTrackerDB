import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AssociateSkillsModel} from '../../Model/AssociateSkillsModel'
import {AssociateServiceService} from '../../Services/associate-service.service'
import { FormGroup, FormBuilder, Validators , ReactiveFormsModule} from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import {SliderModule} from 'primeng/slider';
import { DomSanitizer } from '@angular/platform-browser';
import { debug } from 'util';

@Component({
  selector: 'app-add-associate-skill',
  templateUrl: './add-associate-skill.component.html',
  styleUrls: ['./add-associate-skill.component.css']
})
export class AddAssociateSkillComponent implements OnInit {

  form: FormGroup;
  associateSkill:AssociateSkillsModel;
  errorMessage: string;
  genders:string[] = ['Male','Female'];

  messageDisplay :string=''
  messageType:string=''

  constructor(private _associateservice: AssociateServiceService, private _router: Router,private formBuilder: FormBuilder,
    private confirmationService: ConfirmationService,private domSanitizer: DomSanitizer) { }

    ngOnInit() {
      this.form = this.formBuilder.group({
        name: [null,Validators.required],
        associateid: [null, Validators.required], 
        gender: [null, Validators.required],      
        email: [null, Validators.required],    
        mobile: [null, Validators.required],    
      });
     
      this.ResetPage();
    }
    ResetPage()
    {
      this.getAssociateSkillDetails(0);      
    }
    getAssociateSkillDetails(id:number)
    {
      this._associateservice.GetAssociateSkillDetails(id)
      .subscribe(
      value => this.associateSkill = value,
      error => this.errorMessage = <any>error);
    }
    levelClick(level:string)
    {
        this.associateSkill.AssociateDetails.Level1=false;
        this.associateSkill.AssociateDetails.Level2=false;
        this.associateSkill.AssociateDetails.Level3=false;
        if(level=='l1')
            this.associateSkill.AssociateDetails.Level1=true;
        else if(level=='l2')
            this.associateSkill.AssociateDetails.Level2=true;
        else
            this.associateSkill.AssociateDetails.Level3=true;
    }
    statusClick(status:string)
    {
        this.associateSkill.AssociateDetails.StatusBlue=false;
        this.associateSkill.AssociateDetails.StatusGreen=false;
        this.associateSkill.AssociateDetails.StatusRed=false;
        if(status=='green')
            this.associateSkill.AssociateDetails.StatusGreen=true;
        else if(status=='blue')
            this.associateSkill.AssociateDetails.StatusBlue=true;
        else
            this.associateSkill.AssociateDetails.StatusRed=true;
    }
    ResetDetails(){
      this.ResetPage();
    }

    Cancel()
    {
      this._router.navigate(['DashBoard']);
    }

    SaveDetails(){    
      var vali=this.StatusandLevelValidation()
      if(vali=="")
      {
        this.messageDisplay = "Insertion in progress";this.messageType='info';
        this._associateservice.AddAssociateDetails(this.associateSkill)
        .subscribe(
        value => {this.messageDisplay = value;this.messageType='success';this.Cancel()},
        error => {this.messageDisplay = <any>error;this.messageType='danger'});
      }
      else{
        this.messageDisplay=vali;
        this.messageType="danger"
      }
    }

    StatusandLevelValidation()
    {
      var mess="";
      if(this.associateSkill.AssociateDetails.Level1==false && this.associateSkill.AssociateDetails.Level2==false &&
        this.associateSkill.AssociateDetails.Level3==false)
        mess="Please select a Level"
      if(this.associateSkill.AssociateDetails.StatusBlue==false && this.associateSkill.AssociateDetails.StatusGreen==false &&
        this.associateSkill.AssociateDetails.StatusRed==false)
        mess="Please select a status"
      
        return mess;
    }
    changeListener($event) : void {
      this.readThis($event.target);
    }
    
    readThis(inputValue: any): void {
      var file:File = inputValue.files[0];
      var myReader:FileReader = new FileReader();
    
      myReader.onloadend = (e) => {
        this.associateSkill.AssociateDetails.BasePhoto = myReader.result;
        this.associateSkill.AssociateDetails.UserPhoto=this.associateSkill.AssociateDetails.BasePhoto.replace('-', '+').replace('_', '/')
        .replace("data:image/jpeg;base64,", "");
      }
      myReader.readAsDataURL(file);
    }


}
