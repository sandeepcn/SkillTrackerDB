import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DashBoardComponent } from './dash-board.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { SkillGraphComponent } from '../skill-graph/skill-graph.component';
import { DashBoardFilterPipe } from '../../Pipes/dash-board-filter.pipe';
import { SafeHtmlPipe } from '../../Pipes/safe-html.pipe';
import {AssociateServiceService} from '../../Services/associate-service.service'
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { MessageDisplayComponent } from '../../UI/message-display/message-display.component';
import { RouterTestingModule } from '@angular/router/testing';
import {ConfirmationService} from 'primeng/api';

describe('DashBoardComponent', () => {
  let component: DashBoardComponent;
  let fixture: ComponentFixture<DashBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashBoardComponent,SkillGraphComponent,DashBoardFilterPipe,SafeHtmlPipe,MessageDisplayComponent ],
      imports:[FormsModule,ReactiveFormsModule,ConfirmDialogModule,RouterTestingModule,HttpModule,BrowserModule],
      providers:[AssociateServiceService,ConfirmationService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
