import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {DashBoardModel} from '../../Model/DashBoardModel'
import {AssociateServiceService} from '../../Services/associate-service.service'
import { FormGroup, FormBuilder, Validators , ReactiveFormsModule} from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {
  form: FormGroup;
  dashBoardModel:DashBoardModel;
  errorMessage: string;
  messageDisplay :string=''
  messageType:string=''

  constructor(private _associateservice: AssociateServiceService, private _router: Router,private formBuilder: FormBuilder,
    private confirmationService: ConfirmationService) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      skillz: [null,Validators.required]        
    });
    this.messageDisplay="Dashboard details are getting loaded... Please wait...";
    this.messageType="info";
    this.ResetPage();
  }
  ResetPage()
  {
    this.getDashBoardDetails();      
  }
  getDashBoardDetails()
  {
    this._associateservice.GetDashBoardData()
      .subscribe(
      value => {this.dashBoardModel = value;this.messageDisplay="";
      this.messageType="";},
      error => this.errorMessage = <any>error);
  }
 
  DeleteAssociate(associateId:number)
  {    
  this.confirmationService.confirm({
    message: 'Do you want to delete this Associate?',
    accept: () => {
    this._associateservice.DeleteAssociateDetails(associateId)
          .subscribe(
            value => {this.messageDisplay = value;this.messageType='success';this.getDashBoardDetails()},
            error => {this.messageDisplay = <any>error;this.messageType='danger'});
          }
        });
  }
}
