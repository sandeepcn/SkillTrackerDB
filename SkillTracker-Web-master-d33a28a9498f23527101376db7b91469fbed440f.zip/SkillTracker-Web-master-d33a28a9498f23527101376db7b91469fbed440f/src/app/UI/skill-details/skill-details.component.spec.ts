import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SkillDetailsComponent } from './skill-details.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DialogModule} from 'primeng/dialog';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MessageDisplayComponent } from '../message-display/message-display.component';
import { SkillFilterPipe } from '../../Pipes/skill-filter.pipe';
import {SkillServiceService} from '../../Services/skill-service.service'
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import {ConfirmationService} from 'primeng/api';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('SkillDetailsComponent', () => {
  let component: SkillDetailsComponent;
  let fixture: ComponentFixture<SkillDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillDetailsComponent,MessageDisplayComponent,SkillFilterPipe ],
      imports:[ConfirmDialogModule,DialogModule,ReactiveFormsModule,FormsModule,HttpModule,RouterTestingModule,BrowserAnimationsModule],
      providers:[SkillServiceService,ConfirmationService]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
