import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillGraphComponent } from './skill-graph.component';
import { SafeHtmlPipe } from '../../Pipes/safe-html.pipe';

describe('SkillGraphComponent', () => {
  let component: SkillGraphComponent;
  let fixture: ComponentFixture<SkillGraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillGraphComponent,SafeHtmlPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
