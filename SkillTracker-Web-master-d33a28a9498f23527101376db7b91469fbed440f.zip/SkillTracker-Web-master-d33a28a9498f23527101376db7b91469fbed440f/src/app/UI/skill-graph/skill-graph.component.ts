import { Component, OnChanges ,Input,Output,EventEmitter} from '@angular/core';
import {GraphModel} from '../../Model/GraphModel'
@Component({
  selector: 'app-skill-graph',
  templateUrl: './skill-graph.component.html',
  styleUrls: ['./skill-graph.component.css']
})
export class SkillGraphComponent implements OnChanges {

  @Input() graphDetails:GraphModel[]
  dynamicHtml:string;
  constructor() { }

  ngOnChanges():void{
    this.dynamicHtml="";
    if(typeof this.graphDetails !== 'undefined' && this.graphDetails.length > 0)
    for (let det of this.graphDetails) {       
      this.dynamicHtml+="<div  style='margin-left:0px;width:"+det.Percent.toString()
      +"%;height:163px;float:left;background-color:"
      +det.Color.toLowerCase()+"'><div class='graph_item' style='line-height: 10'>"
      +'<b>'+det.SkillName+'</b>'+
      "</div></div>"
    }
  }

}
