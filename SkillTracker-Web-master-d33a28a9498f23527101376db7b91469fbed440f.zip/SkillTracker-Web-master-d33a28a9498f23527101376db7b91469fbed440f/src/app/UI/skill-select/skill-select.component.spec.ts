import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SkillSelectComponent } from './skill-select.component';
import { AssociateSkillFilterPipe } from '../../Pipes/associate-skill-filter.pipe';
import {SliderModule} from 'primeng/slider'; 
import { FormsModule } from '@angular/forms';

describe('SkillSelectComponent', () => {
  let component: SkillSelectComponent;
  let fixture: ComponentFixture<SkillSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillSelectComponent,AssociateSkillFilterPipe ],
      imports:[SliderModule,FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
