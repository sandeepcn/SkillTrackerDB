import { Component, OnChanges ,Input,Output,EventEmitter} from '@angular/core';
import {AssociateSkillMappingModel} from '../../Model/AssociateSkillMappingModel'
@Component({
  selector: 'app-skill-select',
  templateUrl: './skill-select.component.html',
  styleUrls: ['./skill-select.component.css']
})
export class SkillSelectComponent implements OnChanges {

  @Input() associateSkill:AssociateSkillMappingModel[]
  @Input() isDisabled:boolean;
  @Input() filterString:string;
   constructor() { }  

  ngOnChanges():void{
    
  }


}
