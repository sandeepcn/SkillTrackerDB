import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAssociateSkillComponent } from './update-associate-skill.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SkillSelectComponent } from '../skill-select/skill-select.component';
import { AssociateSkillFilterPipe } from '../../Pipes/associate-skill-filter.pipe';
import {SliderModule} from 'primeng/slider'; 
import {AssociateServiceService} from '../../Services/associate-service.service'
import {SkillServiceService} from '../../Services/skill-service.service'
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { MessageDisplayComponent } from '../../UI/message-display/message-display.component';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import {ConfirmationService} from 'primeng/api';

describe('UpdateAssociateSkillComponent', () => {
  let component: UpdateAssociateSkillComponent;
  let fixture: ComponentFixture<UpdateAssociateSkillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateAssociateSkillComponent ,SkillSelectComponent,AssociateSkillFilterPipe,MessageDisplayComponent ],
      imports:[ReactiveFormsModule,FormsModule,SliderModule,ConfirmDialogModule,HttpModule,RouterTestingModule],
      providers:[AssociateServiceService,SkillServiceService,ConfirmationService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAssociateSkillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
