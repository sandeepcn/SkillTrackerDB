import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import {AssociateSkillsModel} from '../../Model/AssociateSkillsModel'
import {AssociateServiceService} from '../../Services/associate-service.service'
import {SkillServiceService} from '../../Services/skill-service.service'
import { FormGroup, FormBuilder, Validators , ReactiveFormsModule} from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import {SliderModule} from 'primeng/slider';
import { SkillDetailsModel } from '../../Model/SkillDetailsModel';


@Component({
  selector: 'app-update-associate-skill',
  templateUrl: './update-associate-skill.component.html',
  styleUrls: ['./update-associate-skill.component.css']
})
export class UpdateAssociateSkillComponent implements OnInit {
  form: FormGroup;
  associateSkill:AssociateSkillsModel;
  errorMessage: string;
  genders:string[] = ['Male','Female'];

  messageDisplay :string=''
  messageType:string=''
  private sub:Subscription;    
  
  skillFilter:string;
  skillName:string;
  constructor(private _associateservice: AssociateServiceService,private _skillservice: SkillServiceService, private _router: Router,private _route:ActivatedRoute,
    private formBuilder: FormBuilder, private confirmationService: ConfirmationService) { }
  ngOnInit() {
    this.form = this.formBuilder.group({
      name: [null,Validators.required],
      associateid: [null, Validators.required], 
      gender: [null, Validators.required],      
      email: [null, Validators.required],    
      mobile: [null, Validators.required],    
    });
   
    this.sub=this._route.params.subscribe(
      params => {
        let id=+params['id'];                    
        this.ResetPage(id);
      } 
    )     
  }

  ResetPage(id:number)
  {
    this.getAssociateSkillDetails(id);      
  }
  getAssociateSkillDetails(id:number)
  {
    this._associateservice.GetAssociateSkillDetails(id)
    .subscribe(
    value => this.associateSkill = value,
    error => this.errorMessage = <any>error);
  }
  levelClick(level:string)
  {
      this.associateSkill.AssociateDetails.Level1=false;
      this.associateSkill.AssociateDetails.Level2=false;
      this.associateSkill.AssociateDetails.Level3=false;
      if(level=='l1')
          this.associateSkill.AssociateDetails.Level1=true;
      else if(level=='l2')
          this.associateSkill.AssociateDetails.Level2=true;
      else
          this.associateSkill.AssociateDetails.Level3=true;
  }
  statusClick(status:string)
  {
      this.associateSkill.AssociateDetails.StatusBlue=false;
      this.associateSkill.AssociateDetails.StatusGreen=false;
      this.associateSkill.AssociateDetails.StatusRed=false;
      if(status=='green')
          this.associateSkill.AssociateDetails.StatusGreen=true;
      else if(status=='blue')
          this.associateSkill.AssociateDetails.StatusBlue=true;
      else
          this.associateSkill.AssociateDetails.StatusRed=true;
  }
   
  DeleteAssociate(associateId:number)
  {    
  this.confirmationService.confirm({
    message: 'Do you want to delete this Associate?',
    accept: () => {
    this._associateservice.DeleteAssociateDetails(associateId)
          .subscribe(
            value => {this.messageDisplay = value;this.messageType='success';this.Cancel()},
            error => {this.messageDisplay = <any>error;this.messageType='danger'});
          }
        });
  }

  Cancel()
  {
    this._router.navigate(['DashBoard']);
  }

  SaveDetails(){
  var vali=this.StatusandLevelValidation()
  if(vali=="")
    {
      this.messageDisplay = "Updation in progress";this.messageType='info';
      this._associateservice.UpdateAssociateDetails(this.associateSkill)
      .subscribe(
      value => {this.messageDisplay = value;this.messageType='success';this.Cancel()},
      error => {this.messageDisplay = <any>error;this.messageType='danger'});
    }   
  else{
    this.messageDisplay=vali;
    this.messageType="danger"
    }
  }

  StatusandLevelValidation()
    {
      var mess="";
      if(this.associateSkill.AssociateDetails.Level1==false && this.associateSkill.AssociateDetails.Level2==false &&
        this.associateSkill.AssociateDetails.Level3==false)
        mess="Please select a Level"
      if(this.associateSkill.AssociateDetails.StatusBlue==false && this.associateSkill.AssociateDetails.StatusGreen==false &&
        this.associateSkill.AssociateDetails.StatusRed==false)
        mess="Please select a status"
      
        return mess;
    }

    changeListener($event) : void {
      this.readThis($event.target);
    }
    
    readThis(inputValue: any): void {
      var file:File = inputValue.files[0];
      var myReader:FileReader = new FileReader();
    
      myReader.onloadend = (e) => {
        this.associateSkill.AssociateDetails.BasePhoto = myReader.result;
        this.associateSkill.AssociateDetails.UserPhoto=this.associateSkill.AssociateDetails.BasePhoto.replace('-', '+').replace('_', '/')
        .replace("data:image/jpeg;base64,", "");
      }
      myReader.readAsDataURL(file);
    }

  AddSkill()
  {
    if(this.skillName.replace(/\s/g, "").length > 0)
    {   
      var skill=new SkillDetailsModel(0,this.skillName)
      this._skillservice.AddSkill(skill)
          .subscribe(
          value => {this.messageDisplay = value;this.messageType='success';this.GetAssociateSkill()},
          error => {this.messageDisplay = <any>error;this.messageType='danger'});
    }
 }

 GetAssociateSkill()
 {
  this._associateservice.GetAssociateSkillInfo(this.associateSkill.AssociateDetails.AssociateDetailsID)
    .subscribe(
    value => {this.associateSkill.Skills = value,this.skillName=''},
    error => this.errorMessage = <any>error);
 }

}
