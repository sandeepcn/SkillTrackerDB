import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewAssociateDetailsComponent } from './view-associate-details.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SkillSelectComponent } from '../skill-select/skill-select.component';
import { AssociateSkillFilterPipe } from '../../Pipes/associate-skill-filter.pipe';
import {SliderModule} from 'primeng/slider'; 
import {AssociateServiceService} from '../../Services/associate-service.service'
import { HttpModule } from '@angular/http';
import {ActivatedRoute} from '@angular/router';
import {DebugElement} from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {Observable} from 'rxjs';
import { Injectable } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import {ConfirmationService} from 'primeng/api';

@Injectable()
export class ActivatedRouteStub
{
    private subject = new BehaviorSubject(this.testParams);
    params = this.subject.asObservable();

    private _testParams: {};
    get testParams() { return this._testParams; }
    set testParams(params: {}) {
        
        this._testParams = params;
        this.subject.next(params);
    }
}


describe('ViewAssociateDetailsComponent', () => {
  let component: ViewAssociateDetailsComponent;
  let fixture: ComponentFixture<ViewAssociateDetailsComponent>;

  let mockParams, mockActivatedRoute;  
  let debugElement: DebugElement;
  let element: HTMLElement;

  beforeEach(async(() => {
    mockActivatedRoute = new ActivatedRouteStub();
    TestBed.configureTestingModule({
      declarations: [ ViewAssociateDetailsComponent,SkillSelectComponent,AssociateSkillFilterPipe ],
      imports:[ReactiveFormsModule,FormsModule,SliderModule,HttpModule,RouterTestingModule],
      providers:[{provide: ActivatedRoute, useValue: mockActivatedRoute},AssociateServiceService,ConfirmationService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAssociateDetailsComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    element = debugElement.nativeElement;
    mockActivatedRoute.testParams = {id: 3};
    fixture.detectChanges();
  });

  it('should set foo to "3"', () => {
    expect(component.id).toBe(3);
  });
});
