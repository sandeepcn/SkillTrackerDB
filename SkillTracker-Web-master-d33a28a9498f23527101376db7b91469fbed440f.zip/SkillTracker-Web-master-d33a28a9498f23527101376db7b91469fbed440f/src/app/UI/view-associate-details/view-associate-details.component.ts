import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import {AssociateSkillsModel} from '../../Model/AssociateSkillsModel'
import {AssociateServiceService} from '../../Services/associate-service.service'
import { FormGroup, FormBuilder, Validators , ReactiveFormsModule} from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import {SliderModule} from 'primeng/slider';


@Component({
  selector: 'app-view-associate-details',
  templateUrl: './view-associate-details.component.html',
  styleUrls: ['./view-associate-details.component.css']
})
export class ViewAssociateDetailsComponent implements OnInit {
  associateSkill:AssociateSkillsModel;   
  private sub:Subscription;  
  errorMessage: string;
  id:number;
  constructor(private _associateservice: AssociateServiceService, private _router: Router,private _route:ActivatedRoute,
    private formBuilder: FormBuilder, private confirmationService: ConfirmationService) { }  

ngOnInit() {   
  this.sub=this._route.params.subscribe(
    params => {
      this.id=+params['id'];                    
      this.ResetPage(this.id);
    } 
  )     
}
ResetPage(id:number)
{
  this.getAssociateSkillDetails(id);      
}
getAssociateSkillDetails(id:number)
{
  this._associateservice.GetAssociateSkillDetails(id)
  .subscribe(
  value => this.associateSkill = value,
  error => this.errorMessage = <any>error);
}
Cancel()
  {
    this._router.navigate(['DashBoard']);
  }
}
