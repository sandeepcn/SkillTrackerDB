import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http'; 
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { DashBoardComponent } from './UI/dash-board/dash-board.component';
import {RouterModule, Routes} from '@angular/router';  
import { SkillDetailsComponent } from './UI/skill-details/skill-details.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { AddAssociateSkillComponent } from './UI/add-associate-skill/add-associate-skill.component';
import { UpdateAssociateSkillComponent } from './UI/update-associate-skill/update-associate-skill.component';
import { SkillFilterPipe } from './Pipes/skill-filter.pipe';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MessageDisplayComponent } from './UI/message-display/message-display.component';

import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {SliderModule} from 'primeng/slider'; 
import { DashBoardFilterPipe } from './Pipes/dash-board-filter.pipe';
import { SkillGraphComponent } from './UI/skill-graph/skill-graph.component';
import { SafeHtmlPipe } from './Pipes/safe-html.pipe';
import { SkillSelectComponent } from './UI/skill-select/skill-select.component';
import { ViewAssociateDetailsComponent } from './UI/view-associate-details/view-associate-details.component';
import { AssociateSkillFilterPipe } from './Pipes/associate-skill-filter.pipe';


@NgModule({
  declarations: [
    AppComponent,
    DashBoardComponent,
    SkillDetailsComponent,
    AddAssociateSkillComponent,
    UpdateAssociateSkillComponent,
    SkillFilterPipe,
    MessageDisplayComponent, 
    DashBoardFilterPipe, 
    SkillGraphComponent, 
    SafeHtmlPipe,      
    SkillSelectComponent, 
    ViewAssociateDetailsComponent, 
    AssociateSkillFilterPipe,     
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    DialogModule,
    ConfirmDialogModule,
    SliderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
